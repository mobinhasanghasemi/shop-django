(function ($) {
	
	"use strict";
	$('.owl-men-item').owlCarousel({
		items:5,
		loop:true,
		dots: true,
		nav: true,
		margin:30,
		  responsive:{
			  0:{
				  items:1
			  },
			  600:{
				  items:2
			  },
			  1000:{
				  items:3
			  }
		 }
	})

	$('.owl-women-item').owlCarousel({
		items:5,
		loop:true,
		dots: true,
		nav: true,
		margin:30,
		  responsive:{
			  0:{
				  items:1
			  },
			  600:{
				  items:2
			  },
			  1000:{
				  items:3
			  }
		 }
	 })

	$('.owl-kid-item').owlCarousel({
		items:5,
		loop:true,
		dots: true,
		nav: true,
		margin:30,
		  responsive:{
			  0:{
				  items:1
			  },
			  600:{
				  items:2
			  },
			  1000:{
				  items:3
			  }
		 }
	 })

	$(window).scroll(function() {
	  var scroll = $(window).scrollTop();
	  var box = $('#top').height();
	  var header = $('header').height();

	  if (scroll >= box - header) {
	    $("header").addClass("background-header");
	  } else {
	    $("header").removeClass("background-header");
	  }
	});
	

	// Window Resize Mobile Menu Fix
	mobileNav();


	// Scroll animation init
	window.sr = new scrollReveal();
	

	// Menu Dropdown Toggle
	if($('.menu-trigger').length){
		$(".menu-trigger").on('click', function() {	
			$(this).toggleClass('active');
			$('.header-area .nav').slideToggle(200);
		});
	}


	// Menu elevator animation
	$('.scroll-to-section a[href*=\\#]:not([href=\\#])').on('click', function() {
		if (location.pathname.replace(/^\//,'') == this.pathname.replace(/^\//,'') && location.hostname == this.hostname) {
			var target = $(this.hash);
			target = target.length ? target : $('[name=' + this.hash.slice(1) +']');
			if (target.length) {
				var width = $(window).width();
				if(width < 991) {
					$('.menu-trigger').removeClass('active');
					$('.header-area .nav').slideUp(200);	
				}				
				$('html,body').animate({
					scrollTop: (target.offset().top) - 80
				}, 700);
				return false;
			}
		}
	});

	$(document).ready(function () {
	    $(document).on("scroll", onScroll);
	    
	    //smoothscroll
	    $('.scroll-to-section a[href^="#"]').on('click', function (e) {
	        e.preventDefault();
	        $(document).off("scroll");
	        
	        $('.scroll-to-section a').each(function () {
	            $(this).removeClass('active');
	        })
	        $(this).addClass('active');
	      
	        var target = this.hash,
	        menu = target;
	       	var target = $(this.hash);
	        $('html, body').stop().animate({
	            scrollTop: (target.offset().top) - 79
	        }, 500, 'swing', function () {
	            window.location.hash = target;
	            $(document).on("scroll", onScroll);
	        });
	    });
	});

	function onScroll(event){
	    var scrollPos = $(document).scrollTop();
	    $('.nav a').each(function () {
	        var currLink = $(this);
	        var refElement = $(currLink.attr("href"));
	        if (refElement.position().top <= scrollPos && refElement.position().top + refElement.height() > scrollPos) {
	            $('.nav ul li a').removeClass("active");
	            currLink.addClass("active");
	        }
	        else{
	            currLink.removeClass("active");
	        }
	    });
	}


	// Page loading animation
	$(window).on('load', function() {
		if($('.cover').length){
			$('.cover').parallax({
				imageSrc: $('.cover').data('image'),
				zIndex: '1'
			});
		}

		$("#preloader").animate({
			'opacity': '0'
		}, 600, function(){
			setTimeout(function(){
				$("#preloader").css("visibility", "hidden").fadeOut();
			}, 300);
		});
	});


	// Window Resize Mobile Menu Fix
	$(window).on('resize', function() {
		mobileNav();
	});


	// Window Resize Mobile Menu Fix
	function mobileNav() {
		var width = $(window).width();
		$('.submenu').on('click', function() {
			if(width < 767) {
				$('.submenu ul').removeClass('active');
				$(this).find('ul').toggleClass('active');
			}
		});
	}
	


})(window.jQuery);



$(document).ready(function () {
    // بارگذاری تعداد سبد خرید در ابتدا
    loadCartCount();

    // اضافه کردن محصول به سبد خرید
    $(document).on('click', '.add-to-cart-btn, #add-to-cart-btn', function(e) {
        e.preventDefault();
        const btn = $(this);
        const productId = btn.data('id');
        const quantity = parseInt($('#cartprice').val()) || 1;

        // نمایش لودینگ
        btn.prop('disabled', true).html('<i class="fa fa-spinner fa-spin me-1"></i>در حال اضافه کردن...');

        $.ajax({
            url: "/add-to-cart/",
            method: "POST",
            data: {
                product_id: productId,
                quantity: quantity,
                csrfmiddlewaretoken: $('meta[name=csrf-token]').attr('content')
            },
            success: function(response) {
                if (response.status === 'ok') {
                    // نمایش پیام موفقیت
                    showNotification('محصول با موفقیت به سبد خرید اضافه شد!', 'success');
                    
                    // آپدیت تعداد سبد خرید
                    $('#cart-count').text(response.cart_count);
                    
                    // باز کردن مودال سبد خرید
                    $('#cartModal').modal('show');
                    
                    // بارگذاری محتوای سبد خرید
                    loadCartContent();
                } else {
                    showNotification('خطا در اضافه کردن محصول!', 'error');
                }
            },
            error: function() {
                showNotification('خطا در ارتباط با سرور!', 'error');
            },
            complete: function() {
                // بازگردانی دکمه
                btn.prop('disabled', false).html('<i class="fa fa-shopping-cart me-1"></i>افزودن به سبد خرید');
            }
        });
    });

    // آپدیت آیتم‌های سبد خرید
    $(document).on('click', '.update-cart-item', function() {
        const btn = $(this);
        const itemId = btn.data('id');
        const action = btn.data('action');

        // نمایش لودینگ
        btn.prop('disabled', true);

        $.ajax({
            url: "/update-cart-item/",
            method: "POST",
            data: {
                item_id: itemId,
                action: action,
                csrfmiddlewaretoken: $('meta[name=csrf-token]').attr('content')
            },
            success: function(response) {
                if (response.status === 'ok') {
                    // آپدیت تعداد سبد خرید
                    $('#cart-count').text(response.cart_count);
                    
                    // بارگذاری مجدد محتوای سبد خرید
                    loadCartContent();
                    
                    // نمایش پیام
                    if (action === 'remove') {
                        showNotification('محصول از سبد خرید حذف شد!', 'info');
                    }
                }
            },
            error: function() {
                showNotification('خطا در بروزرسانی سبد خرید!', 'error');
            },
            complete: function() {
                // بازگردانی دکمه
                btn.prop('disabled', false);
            }
        });
    });

    // بارگذاری محتوای سبد خرید
    $('#cartModal').on('show.bs.modal', function() {
        loadCartContent();
    });

    // تابع بارگذاری تعداد سبد خرید
    function loadCartCount() {
        $.ajax({
            url: "/cart-count/",
            method: "GET",
            success: function(response) {
                $('#cart-count').text(response.cart_count);
            }
        });
    }

    // تابع بارگذاری محتوای سبد خرید
    function loadCartContent() {
        $.ajax({
            url: "/cart-modal-content/",
            method: "GET",
            success: function(response) {
                $('#cart-body').html(response.cart_html);
            },
            error: function() {
                $('#cart-body').html(`
                    <div class="text-center text-danger">
                        <i class="fa fa-exclamation-triangle fa-2x mb-2"></i>
                        <p>خطا در بارگذاری سبد خرید</p>
                    </div>
                `);
            }
        });
    }

    // تابع نمایش اعلان
    function showNotification(message, type = 'info') {
        const alertClass = type === 'success' ? 'alert-success' : 
                          type === 'error' ? 'alert-danger' : 
                          type === 'warning' ? 'alert-warning' : 'alert-info';
        
        const notification = $(`
            <div class="alert ${alertClass} alert-dismissible fade show position-fixed" 
                 style="top: 20px; right: 20px; z-index: 9999; min-width: 300px;">
                ${message}
                <button type="button" class="close" data-dismiss="alert">
                    <span>&times;</span>
                </button>
            </div>
        `);
        
        $('body').append(notification);
        
        // حذف خودکار بعد از 5 ثانیه
        setTimeout(function() {
            notification.alert('close');
        }, 5000);
    }

    // تابع آپدیت مودال (برای سازگاری با کد قدیمی)
    function updateCartModal() {
        loadCartContent();
    }
});
