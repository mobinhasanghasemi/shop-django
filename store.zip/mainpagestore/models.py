from django.db import models
from ckeditor.fields import RichTextField
from django.contrib.auth.models import User
from django.db.models import F, Sum
from decimal import Decimal
from django.contrib.auth.models import AbstractUser
from django.core.validators import RegexValidator
from django.conf import settings


class Category(models.Model):
    name = models.CharField(max_length=100, unique=True, verbose_name="نام دسته‌بندی")
    description = models.TextField(blank=True, null=True, verbose_name="توضیحات")

    class Meta:
        verbose_name = "دسته‌بندی"
        verbose_name_plural = "دسته‌بندی‌ها"

    def __str__(self):
        return self.name


class Product(models.Model):
    category = models.ForeignKey(Category, on_delete=models.CASCADE, related_name="products", verbose_name="دسته‌بندی")
    name = models.CharField(max_length=200, verbose_name="نام محصول")
    price = models.DecimalField(max_digits=12, decimal_places=0, verbose_name="قیمت")
    description = RichTextField(
        max_length=500,
        help_text="متن کوتاه و جذاب برای نمایش در فید و کارت‌ها"
    )
    image = models.ImageField(upload_to="assets/images", blank=True, null=True, verbose_name="تصویر محصول")
    is_featured = models.BooleanField(default=False, verbose_name="نمایش در اسلایدر")
    is_active = models.BooleanField(default=False, verbose_name="موجود / ناموجود")
    count = models.PositiveIntegerField(default=0, verbose_name="تعداد موجودی")
    created_at = models.DateTimeField(auto_now_add=True, verbose_name="تاریخ ثبت")


    class Meta:
        verbose_name = "محصول"
        verbose_name_plural = "محصولات"
        ordering = ["-created_at"]

    def __str__(self):
        return self.name


class Slider(models.Model):
    category = models.ForeignKey(Category, on_delete=models.CASCADE, related_name="sliders", verbose_name="دسته‌بندی")
    name = models.CharField(max_length=200, verbose_name="عنوان اسلایدر")
    description = models.TextField(max_length=300, blank=True, null=True, verbose_name="توضیحات")
    image = models.ImageField(upload_to="assets/images", blank=True, null=True, verbose_name="تصویر اسلایدر")
    is_active = models.BooleanField(default=True, verbose_name="فعال/غیرفعال")
    created_at = models.DateTimeField(auto_now_add=True, verbose_name="تاریخ ثبت")

    class Meta:
        verbose_name = "اسلایدر"
        verbose_name_plural = "اسلایدرها"
        ordering = ["-created_at"]

    def __str__(self):
        return self.name
class Title(models.Model):
    title = models.CharField(max_length=200, verbose_name="تایتل", blank=False, null=False)

    class Meta:
        verbose_name = 'تایتل'
        verbose_name_plural = 'تایتل‌ها'

    def __str__(self):
        return self.title


class about(models.Model):
    pass


class CustomUser(AbstractUser):
    """مدل کاربر سفارشی با فیلدهای اضافی"""
    phone_regex = RegexValidator(regex=r'^09\d{9}$', message="شماره موبایل باید با 09 شروع شود و 11 رقم باشد")
    phone_number = models.CharField(validators=[phone_regex], max_length=11, blank=True, null=True, verbose_name="شماره موبایل")
    birth_date = models.DateField(blank=True, null=True, verbose_name="تاریخ تولد")
    address = models.TextField(blank=True, null=True, verbose_name="آدرس")
    avatar = models.ImageField(upload_to="avatars/", blank=True, null=True, verbose_name="تصویر پروفایل")
    
    class Meta:
        verbose_name = "کاربر"
        verbose_name_plural = "کاربران"
    
    def __str__(self):
        return self.username


class UserProfile(models.Model):
    """پروفایل کاربر با اطلاعات تکمیلی"""
    user = models.OneToOneField(CustomUser, on_delete=models.CASCADE, related_name='profile', verbose_name="کاربر")
    bio = models.TextField(max_length=500, blank=True, verbose_name="درباره من")
    website = models.URLField(blank=True, verbose_name="وب‌سایت")
    location = models.CharField(max_length=100, blank=True, verbose_name="موقعیت جغرافیایی")
    created_at = models.DateTimeField(auto_now_add=True, verbose_name="تاریخ ایجاد")
    updated_at = models.DateTimeField(auto_now=True, verbose_name="تاریخ بروزرسانی")
    
    class Meta:
        verbose_name = "پروفایل کاربر"
        verbose_name_plural = "پروفایل‌های کاربران"
    
    def __str__(self):
        return f"پروفایل {self.user.username}"

from django.db import models

class ContactMessage(models.Model):
    name = models.CharField(max_length=100, verbose_name="نام")
    email = models.EmailField(verbose_name="ایمیل")
    message = models.TextField(verbose_name="پیام")
    created_at = models.DateTimeField(auto_now_add=True, verbose_name="تاریخ ارسال")

    def __str__(self):
        return f"{self.name} - {self.email}"
    
    class Meta:
        verbose_name = "پیام تماس"
        verbose_name_plural = "پیام‌های تماس"
    

class Cart(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    name = models.CharField(max_length=255, default='Default Cart')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['-updated_at']

    def __str__(self):
        return f"{self.user.username} - {self.name}"

    def total_price(self):
        """
        مجموع قیمت کل آیتم‌ها در سبد با فقط یک کوئری
        """
        result = self.items.aggregate(
            total=Sum(F('price_at_time') * F('quantity'))
        )['total']
        return result or Decimal('0.00')

    def total_items(self):
        return self.items.aggregate(total=Sum('quantity'))['total'] or 0

    def add_product(self, product, quantity=1):
        """
        اضافه کردن یا آپدیت محصول در سبد
        """
        item, created = self.items.get_or_create(
            product=product,
            defaults={
                'quantity': quantity,
                'price_at_time': product.price,
            }
        )
        if not created:
            item.quantity += quantity
            item.save()
        return item

    def remove_product(self, product):
        self.items.filter(product=product).delete()

    def clear(self):
        self.items.all().delete()


class CartItem(models.Model):
    cart = models.ForeignKey(Cart, related_name='items', on_delete=models.CASCADE)
    product = models.ForeignKey('Product', on_delete=models.CASCADE)
    quantity = models.PositiveIntegerField(default=1)
    price_at_time = models.DecimalField(max_digits=10, decimal_places=2)

    class Meta:
        unique_together = ('cart', 'product')
        ordering = ['id']

    def __str__(self):
        return f"{self.product.name} x {self.quantity}"

    @property
    def total_price(self):
        return self.price_at_time * self.quantity

    def save(self, *args, **kwargs):
        if not self.pk:  # new item
            self.price_at_time = self.product.price
        super().save(*args, **kwargs)


class Order(models.Model):
    """مدل سفارش"""
    STATUS_CHOICES = [
        ('pending', 'در انتظار'),
        ('processing', 'در حال پردازش'),
        ('shipped', 'ارسال شده'),
        ('delivered', 'تحویل داده شده'),
        ('cancelled', 'لغو شده'),
    ]
    
    user = models.ForeignKey(CustomUser, on_delete=models.CASCADE, related_name='orders', verbose_name="کاربر")
    order_number = models.CharField(max_length=20, unique=True, verbose_name="شماره سفارش")
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='pending', verbose_name="وضعیت")
    total_amount = models.DecimalField(max_digits=12, decimal_places=0, verbose_name="مبلغ کل")
    shipping_address = models.TextField(verbose_name="آدرس ارسال")
    phone_number = models.CharField(max_length=11, verbose_name="شماره تماس")
    notes = models.TextField(blank=True, null=True, verbose_name="یادداشت")
    created_at = models.DateTimeField(auto_now_add=True, verbose_name="تاریخ سفارش")
    updated_at = models.DateTimeField(auto_now=True, verbose_name="تاریخ بروزرسانی")
    
    class Meta:
        verbose_name = "سفارش"
        verbose_name_plural = "سفارش‌ها"
        ordering = ['-created_at']
    
    def __str__(self):
        return f"سفارش {self.order_number} - {self.user.username}"


class OrderItem(models.Model):
    order = models.ForeignKey(Order, on_delete=models.CASCADE, related_name='items', verbose_name="سفارش")
    product = models.ForeignKey(Product, on_delete=models.CASCADE, verbose_name="محصول")
    quantity = models.PositiveIntegerField(verbose_name="تعداد", null=True, blank=True)
    price_at_time = models.DecimalField(max_digits=10, decimal_places=0, verbose_name="قیمت در زمان سفارش", null=True, blank=True)

    @property
    def total_price(self):
        # اگر None بود، صفر قرار بده
        q = self.quantity or 0
        p = self.price_at_time or 0
        return p * q
