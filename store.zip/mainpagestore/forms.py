from django import forms
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from django.contrib.auth import authenticate
from .models import ContactMessage, CustomUser, UserProfile, Order

class ContactMessageForm(forms.ModelForm):
    class Meta:
        model = ContactMessage
        fields = ['name', 'email', 'message']
        widgets = {
            'name': forms.TextInput(attrs={'placeholder': 'نام شما', 'class': 'form-control'}),
            'email': forms.EmailInput(attrs={'placeholder': 'ایمیل شما', 'class': 'form-control'}),
            'message': forms.Textarea(attrs={'placeholder': 'پیام شما', 'class': 'form-control', 'rows': 6}),
        }


class CustomUserCreationForm(UserCreationForm):
    """فرم ثبت‌نام کاربر"""
    email = forms.EmailField(
        required=True,
        widget=forms.EmailInput(attrs={
            'class': 'form-control',
            'placeholder': 'ایمیل شما',
            'dir': 'ltr'
        })
    )
    phone_number = forms.CharField(
        max_length=11,
        required=True,
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'placeholder': '09123456789',
            'dir': 'ltr'
        })
    )
    first_name = forms.CharField(
        max_length=30,
        required=True,
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'placeholder': 'نام'
        })
    )
    last_name = forms.CharField(
        max_length=30,
        required=True,
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'placeholder': 'نام خانوادگی'
        })
    )

    class Meta:
        model = CustomUser
        fields = ('username', 'first_name', 'last_name', 'email', 'phone_number', 'password1', 'password2')
        widgets = {
            'username': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'نام کاربری',
                'dir': 'ltr'
            }),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['password1'].widget.attrs.update({
            'class': 'form-control',
            'placeholder': 'رمز عبور'
        })
        self.fields['password2'].widget.attrs.update({
            'class': 'form-control',
            'placeholder': 'تکرار رمز عبور'
        })

    def clean_email(self):
        email = self.cleaned_data.get('email')
        if CustomUser.objects.filter(email=email).exists():
            raise forms.ValidationError("این ایمیل قبلاً ثبت شده است.")
        return email

    def clean_phone_number(self):
        phone_number = self.cleaned_data.get('phone_number')
        if not phone_number.startswith('09') or len(phone_number) != 11:
            raise forms.ValidationError("شماره موبایل باید با 09 شروع شود و 11 رقم باشد.")
        if CustomUser.objects.filter(phone_number=phone_number).exists():
            raise forms.ValidationError("این شماره موبایل قبلاً ثبت شده است.")
        return phone_number


class CustomAuthenticationForm(AuthenticationForm):
    """فرم ورود کاربر"""
    username = forms.CharField(
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'placeholder': 'نام کاربری یا ایمیل',
            'dir': 'ltr'
        })
    )
    password = forms.CharField(
        widget=forms.PasswordInput(attrs={
            'class': 'form-control',
            'placeholder': 'رمز عبور'
        })
    )

    def clean(self):
        username = self.cleaned_data.get('username')
        password = self.cleaned_data.get('password')

        if username and password:
            # بررسی ورود با ایمیل یا نام کاربری
            user = authenticate(username=username, password=password)
            if not user:
                # اگر با نام کاربری کار نکرد، با ایمیل امتحان کن
                try:
                    user_obj = CustomUser.objects.get(email=username)
                    user = authenticate(username=user_obj.username, password=password)
                except CustomUser.DoesNotExist:
                    pass
            
            if not user:
                raise forms.ValidationError("نام کاربری یا رمز عبور اشتباه است.")
            
            if not user.is_active:
                raise forms.ValidationError("حساب کاربری شما غیرفعال است.")
            
            self.user_cache = user
        return self.cleaned_data


class UserProfileForm(forms.ModelForm):
    """فرم پروفایل کاربر"""
    class Meta:
        model = UserProfile
        fields = ['bio', 'website', 'location']
        widgets = {
            'bio': forms.Textarea(attrs={
                'class': 'form-control',
                'placeholder': 'درباره خود بنویسید...',
                'rows': 4
            }),
            'website': forms.URLInput(attrs={
                'class': 'form-control',
                'placeholder': 'https://example.com',
                'dir': 'ltr'
            }),
            'location': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'شهر، کشور'
            }),
        }


class OrderForm(forms.ModelForm):
    """فرم سفارش"""
    class Meta:
        model = Order
        fields = ['shipping_address', 'phone_number', 'notes']
        widgets = {
            'shipping_address': forms.Textarea(attrs={
                'class': 'form-control',
                'placeholder': 'آدرس کامل ارسال',
                'rows': 4
            }),
            'phone_number': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': '09123456789',
                'dir': 'ltr'
            }),
            'notes': forms.Textarea(attrs={
                'class': 'form-control',
                'placeholder': 'یادداشت‌های اضافی (اختیاری)',
                'rows': 3
            }),
        }