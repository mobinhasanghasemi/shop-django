from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from django.shortcuts import render, get_object_or_404 , redirect
from django.contrib import messages
from django.http import JsonResponse
from django.contrib.auth import login, logout, authenticate
from django.contrib.auth.decorators import login_required
from django.contrib.auth.forms import UserCreationForm
from django.views.decorators.csrf import csrf_exempt
from django.utils import timezone
from django.db import transaction
from .models import Product , Slider , Title , Cart , CartItem, CustomUser, UserProfile, Order, OrderItem
from .forms import ContactMessageForm, CustomUserCreationForm, CustomAuthenticationForm, UserProfileForm, OrderForm
import json
from decimal import Decimal
import uuid



def home(request):
    products = Product.objects.filter(is_featured=True)  # همه محصولات رو از دیتابیس بگیر
    slid = Slider.objects.all()
    title = Title.objects.first()
    sliders = Slider.objects.filter(is_active=True).values("image")  # فقط فیلدهای مورد نیاز
    sliders_json = json.dumps(list(sliders))
    
    return render(request, 'core/index.html', {'items': products , 'slider':slid , "title":title , "slider_data": sliders_json,})






def single_product(request, product_id):
    title = Title.objects.first()

    product = get_object_or_404(Product, id=product_id)  # محصول با ID مشخص رو بگیر یا خطای 404 بده
    return render(request, 'core/single-product.html', {'product': product , "title":title})





def products(request, Product_category=None):
    title = Title.objects.first()
    
    if Product_category:
        products = Product.objects.filter(category__name=Product_category)
    else:
        products = Product.objects.all()
    
    paginator = Paginator(products, 9)
    page_number = request.GET.get('page')
    
    try:
        page_obj = paginator.page(page_number)
    except (PageNotAnInteger, EmptyPage):
        page_obj = paginator.page(1)  # صفحه اول به‌صورت پیش‌فرض
    
    return render(request, 'core/products.html', {
        'products': page_obj,
        'category': Product_category,
        'title': title,
        'page_obj': page_obj  # برای دسترسی به اطلاعات پیجینگ
    })




def contact(request):
    if request.method == 'POST':
        form = ContactMessageForm(request.POST)
        if form.is_valid():
            form.save()
            if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                return JsonResponse({
                    'ok': True,
                    'message': 'پیام شما با موفقیت ارسال شد.'
                })
            messages.success(request, "پیام شما با موفقیت ارسال شد.")
            return redirect('contact')
        else:
            if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                return JsonResponse({
                    'ok': False,
                    'errors': form.errors
                }, status=400)
    else:
        form = ContactMessageForm()

    return render(request, 'core/contact.html', {'form': form})


def about(request):
    return render(request, 'core/about.html')


def get_cart(request):
    """دریافت یا ایجاد cart از session"""
    return request.session.setdefault('cart', {})


def save_cart(request, cart):
    """ذخیره cart در session"""
    request.session['cart'] = cart
    request.session.modified = True


def calculate_totals(cart):
    """محاسبه تعداد و مجموع قیمت کل"""
    total_qty = sum(item['quantity'] for item in cart.values())
    total_price = sum(Decimal(str(item['price'])) * item['quantity'] for item in cart.values())
    return total_qty, total_price


def add_to_cart(request):
    if request.method != "POST":
        return JsonResponse({'status': 'error', 'message': 'Invalid request'}, status=400)

    product_id = str(request.POST.get('product_id'))
    quantity = int(request.POST.get('quantity', 1))
    product = get_object_or_404(Product, id=product_id)

    cart = get_cart(request)

    if product_id in cart:
        cart[product_id]['quantity'] += quantity
    else:
        cart[product_id] = {
            'name': product.name,
            'price': str(product.price),  # Decimal → string برای JSON compatibility
            'quantity': quantity,
        }

    save_cart(request, cart)
    total_qty, total_price = calculate_totals(cart)

    return JsonResponse({
        'status': 'ok',
        'cart_count': total_qty,
        'total': str(total_price),
    })


def update_cart_item(request):
    if request.method != "POST":
        return JsonResponse({'status': 'error', 'message': 'Invalid request'}, status=400)

    item_id = str(request.POST.get('item_id'))
    action = request.POST.get('action')
    cart = get_cart(request)

    if item_id in cart:
        if action == 'increment':
            cart[item_id]['quantity'] += 1
        elif action == 'decrement':
            cart[item_id]['quantity'] -= 1
            if cart[item_id]['quantity'] <= 0:
                del cart[item_id]
        elif action == 'remove':
            del cart[item_id]

    save_cart(request, cart)
    total_qty, total_price = calculate_totals(cart)

    return JsonResponse({
        'status': 'ok',
        'cart_count': total_qty,
        'total': str(total_price),
    })


# views.py
from decimal import Decimal


# توی پروژه ما این helperها رو داریم
from .views import get_cart, calculate_totals

def cart_modal_content(request):
    """
    ویو AJAX برای مودال سبد خرید
    """
    cart = get_cart(request)  # گرفتن سبد خرید از session
    total_qty, total_price = calculate_totals(cart)

    # رندر بخش HTML کارت (cart_modal_content.html)
    cart_html = render(request, 'core/cart_modal_content.html', {
        'cart': cart,
        'total_price': total_price
    }).content.decode('utf-8')  # تبدیل به رشته برای JSON

    return JsonResponse({
        'cart_html': cart_html,
        'total_qty': total_qty,
        'total_price': str(total_price)
    })


def checkout(request):
    return render(request, 'core/cart_modal_content.html')


# ==================== احراز هویت ====================

def register_view(request):
    """صفحه ثبت‌نام"""
    if request.method == 'POST':
        form = CustomUserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            # ایجاد پروفایل کاربر
            UserProfile.objects.create(user=user)
            messages.success(request, 'حساب کاربری شما با موفقیت ایجاد شد!')
            login(request, user)
            return redirect('dashboard')
    else:
        form = CustomUserCreationForm()
    
    return render(request, 'core/register.html', {'form': form})


def login_view(request):
    """صفحه ورود"""
    if request.method == 'POST':
        form = CustomAuthenticationForm(data=request.POST)
        if form.is_valid():
            user = form.get_user()
            login(request, user)
            messages.success(request, f'خوش آمدید {user.first_name}!')
            return redirect('dashboard')
    else:
        form = CustomAuthenticationForm()
    
    return render(request, 'core/login.html', {'form': form})


def logout_view(request):
    """خروج از حساب کاربری"""
    logout(request)
    messages.info(request, 'شما با موفقیت خارج شدید.')
    return redirect('home')


@login_required
def dashboard(request):
    """پنل کاربری"""
    user = request.user
    orders = Order.objects.filter(user=user)[:5]  # آخرین 5 سفارش
    cart = get_cart(request)
    total_qty, total_price = calculate_totals(cart)
    
    context = {
        'user': user,
        'orders': orders,
        'cart_count': total_qty,
        'cart_total': total_price,
    }
    return render(request, 'core/dashboard.html', context)


@login_required
def profile_view(request):
    """صفحه پروفایل کاربر"""
    user = request.user
    profile, created = UserProfile.objects.get_or_create(user=user)
    
    if request.method == 'POST':
        form = UserProfileForm(request.POST, instance=profile)
        if form.is_valid():
            form.save()
            messages.success(request, 'پروفایل شما با موفقیت بروزرسانی شد!')
            return redirect('profile')
    else:
        form = UserProfileForm(instance=profile)
    
    return render(request, 'core/profile.html', {'form': form, 'user': user, 'profile': profile})


@login_required
def orders_view(request):
    """صفحه سفارش‌های کاربر"""
    orders = Order.objects.filter(user=request.user)
    return render(request, 'core/orders.html', {'orders': orders})


@login_required
def order_detail(request, order_id):
    """جزئیات سفارش"""
    order = get_object_or_404(Order, id=order_id, user=request.user)
    return render(request, 'core/order_detail.html', {'order': order})


# ==================== بهبود سبد خرید ====================

@login_required
def create_order(request):
    """ایجاد سفارش از سبد خرید"""
    if request.method == 'POST':
        form = OrderForm(request.POST)
        if form.is_valid():
            cart = get_cart(request)
            if not cart:
                messages.error(request, 'سبد خرید شما خالی است!')
                return redirect('home')
            
            with transaction.atomic():
                # ایجاد سفارش
                order = Order.objects.create(
                    user=request.user,
                    order_number=str(uuid.uuid4())[:8].upper(),
                    shipping_address=form.cleaned_data['shipping_address'],
                    phone_number=form.cleaned_data['phone_number'],
                    notes=form.cleaned_data['notes'],
                    total_amount=calculate_totals(cart)[1]
                )
                
                # ایجاد آیتم‌های سفارش
                for product_id, item in cart.items():
                    product = get_object_or_404(Product, id=product_id)
                    OrderItem.objects.create(
                        order=order,
                        product=product,
                        quantity=item['quantity'],
                        price_at_time=product.price
                    )
                
                # پاک کردن سبد خرید
                request.session['cart'] = {}
                request.session.modified = True
                
                messages.success(request, f'سفارش شما با شماره {order.order_number} ثبت شد!')
                return redirect('order_detail', order_id=order.id)
    else:
        form = OrderForm()
    
    return render(request, 'core/checkout.html', {'form': form})


def get_cart_count(request):
    """دریافت تعداد آیتم‌های سبد خرید"""
    cart = get_cart(request)
    total_qty, total_price = calculate_totals(cart)
    return JsonResponse({
        'cart_count': total_qty,
        'cart_total': str(total_price)
    })