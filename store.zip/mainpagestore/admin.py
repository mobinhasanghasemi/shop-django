from django.contrib import admin
from django.utils.safestring import mark_safe
from django.http import HttpResponse
from django.contrib.auth.admin import UserAdmin
from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, PatternFill, Border, Side
from .models import (
    Product, Category, Slider, Title,
    ContactMessage, CustomUser, UserProfile,
    Order, OrderItem
)

# ===============================
# CustomUser Admin
# ===============================
@admin.register(CustomUser)
class CustomUserAdmin(UserAdmin):
    model = CustomUser
    list_display = ('username', 'email', 'phone_number', 'is_staff', 'is_active', 'date_joined')
    list_filter = ('is_staff', 'is_active')
    search_fields = ('username', 'email', 'phone_number')
    ordering = ('id',)
    readonly_fields = ('date_joined', 'last_login')
    
    fieldsets = (
        (None, {'fields': ('username', 'password')}),
        ('اطلاعات شخصی', {'fields': ('first_name', 'last_name', 'email', 'phone_number', 'birth_date', 'avatar', 'address')}),
        ('دسترسی‌ها', {'fields': ('is_active', 'is_staff', 'is_superuser', 'groups', 'user_permissions')}),
        ('تاریخ‌ها', {'fields': ('last_login', 'date_joined')}),
    )
    
    add_fieldsets = (
        (None, {
            'classes': ('wide',),
            'fields': ('username', 'phone_number', 'password1', 'password2', 'is_staff', 'is_active')}
        ),
    )

# ===============================
# UserProfile Admin
# ===============================
@admin.register(UserProfile)
class UserProfileAdmin(admin.ModelAdmin):
    list_display = ('user', 'location', 'website', 'created_at')
    search_fields = ('user__username', 'user__email', 'location')
    list_filter = ('created_at',)

# ===============================
# Product Admin
# ===============================
@admin.register(Product)
class ProductAdmin(admin.ModelAdmin):
    list_display = (
        'thumbnail',
        'name',
        'category',
        'price',
        'count',
        'stock_value',
        'low_stock_alert',
        'is_active',
        'is_featured',
        'created_at',
    )
    readonly_fields = ('created_at', 'similar_products', 'thumbnail')
    list_editable = ('is_active', 'is_featured', 'count')
    search_fields = ('name', 'description')
    list_filter = ('category', 'is_active', 'is_featured')
    ordering = ('-id',)
    list_per_page = 20
    actions = ['export_inventory_excel_advanced']

    # تصویر کوچک
    def thumbnail(self, obj):
        if obj.image:
            return mark_safe(f'<img src="{obj.image.url}" width="50" height="50" />')
        return "No Image"
    thumbnail.short_description = "تصویر"

    # محصولات مشابه
    def similar_products(self, obj):
        if not obj.pk:
            return "محصول هنوز ذخیره نشده."
        if not obj.category:
            return "دسته‌بندی مشخص نشده."
        qs = Product.objects.filter(category=obj.category).exclude(pk=obj.pk)[:5]
        if not qs.exists():
            return "محصول مشابهی یافت نشد."
        html = ""
        for p in qs:
            html += f'<span class="badge badge-info m-1">{p.name} ({p.count})</span>'
        return mark_safe(html)
    similar_products.short_description = "محصولات مشابه"

    # ارزش کل موجودی
    def stock_value(self, obj):
        return f"{obj.price * obj.count:,} تومان"
    stock_value.short_description = "ارزش کل موجودی"

    # هشدار موجودی کم
    def low_stock_alert(self, obj):
        threshold = 5
        if obj.count <= threshold:
            return mark_safe(f'<span class="badge badge-danger">کم ({obj.count})</span>')
        return mark_safe(f'<span class="badge badge-success">{obj.count}</span>')
    low_stock_alert.short_description = "وضعیت موجودی"

    # دانلود اکسل پیشرفته
    def export_inventory_excel_advanced(self, request, queryset):
        if not queryset.exists():
            queryset = Product.objects.all()
        wb = Workbook()
        ws = wb.active
        ws.title = "گزارش موجودی"

        header_font = Font(bold=True, color="FFFFFF")
        header_fill = PatternFill("solid", fgColor="4F81BD")
        border = Border(left=Side(style='thin'), right=Side(style='thin'),
                        top=Side(style='thin'), bottom=Side(style='thin'))

        headers = ['نام', 'دسته‌بندی', 'قیمت', 'موجودی']
        ws.append(headers)
        for cell in ws[1]:
            cell.font = header_font
            cell.fill = header_fill
            cell.alignment = Alignment(horizontal='right')
            cell.border = border

        for product in queryset:
            ws.append([
                product.name,
                product.category.name if product.category else 'بدون دسته‌بندی',
                product.price,
                product.count
            ])
        for row in ws.iter_rows(min_row=2):
            for cell in row:
                cell.alignment = Alignment(horizontal='right')
                cell.border = border

        ws.column_dimensions['A'].width = 30
        ws.column_dimensions['B'].width = 20
        ws.column_dimensions['C'].width = 15
        ws.column_dimensions['D'].width = 10

        response = HttpResponse(content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
        response['Content-Disposition'] = 'attachment; filename="inventory_report_advanced.xlsx"'
        wb.save(response)
        return response
    export_inventory_excel_advanced.short_description = "دانلود اکسل پیشرفته موجودی محصولات"

# ===============================
# Category, Slider, Title Admin
# ===============================
@admin.register(Category)
class CategoryAdmin(admin.ModelAdmin):
    list_display = ('name',)
    search_fields = ('name',)
    list_per_page = 20

@admin.register(Slider)
class SliderAdmin(admin.ModelAdmin):
    list_display = ('name',)
    search_fields = ('name',)
    list_per_page = 20

@admin.register(Title)
class TitleAdmin(admin.ModelAdmin):
    list_display = ('title',)
    search_fields = ('title',)
    list_per_page = 20

# ===============================
# ContactMessage Admin
# ===============================
@admin.register(ContactMessage)
class ContactMessageAdmin(admin.ModelAdmin):
    list_display = ("name", "email", "created_at", "short_message")
    list_filter = ("created_at",)
    search_fields = ("name", "email", "message")

    def short_message(self, obj):
        if len(obj.message) > 50:
            return obj.message[:50] + "..."
        return obj.message
    short_message.short_description = "متن پیام"

# ===============================
# OrderItem Model Fix
# ===============================
# مطمئن شو که این متد داخل کلاس OrderItem در models.py باشه
# class OrderItem(models.Model):
# ...
#     @property
#     def total_price(self):
#         try:
#             return (self.price_at_time or 0) * (self.quantity or 0)
#         except TypeError:
#             return 0

# ===============================
# OrderItem Inline
# ===============================
class OrderItemInline(admin.TabularInline):
    model = OrderItem
    extra = 0
    readonly_fields = ('product', 'price_at_time', 'total_price')
    can_delete = False
    verbose_name = "آیتم سفارش"
    verbose_name_plural = "آیتم‌های سفارش"

# ===============================
# Order Admin
# ===============================
@admin.register(Order)
class OrderAdmin(admin.ModelAdmin):
    list_display = (
        'order_number',
        'user',
        'status',
        'total_amount_display',
        'phone_number',
        'created_at',
        'updated_at',
    )
    list_filter = ('status', 'created_at', 'updated_at')
    search_fields = ('order_number', 'user__username', 'user__phone_number', 'phone_number')
    ordering = ('-created_at',)
    readonly_fields = ('created_at', 'updated_at', 'total_amount_display')
    inlines = [OrderItemInline]
    
    fieldsets = (
        ("اطلاعات سفارش", {
            'fields': ('order_number', 'user', 'status', 'total_amount_display', 'notes')
        }),
        ("اطلاعات تماس و ارسال", {
            'fields': ('shipping_address', 'phone_number')
        }),
        ("تاریخ‌ها", {
            'fields': ('created_at', 'updated_at')
        }),
    )

    def total_amount_display(self, obj):
        total = sum([item.total_price for item in obj.items.all()])
        return f"{total:,} تومان"
    total_amount_display.short_description = "مبلغ کل"
