from django.urls import path
from . import views

urlpatterns = [
    # صفحه اصلی
    path('', views.home, name='home'),

    # صفحه محصول تکی
    path('single-product/<int:product_id>/', views.single_product, name='single_product'),

    # صفحه محصولات با فیلتر دسته‌بندی
    path('products/<str:Product_category>/', views.products , name='products'),

    # همه محصولات
    path('products/', views.products, name='products_all'),

    # تماس با ما
    path('contact/' , views.contact , name='contact' ),

    # درباره ما
    path('about/' , views.about , name='about'),

    # سبد خرید - افزودن محصول
    path('add-to-cart/', views.add_to_cart, name='add_to_cart'),

    # سبد خرید - آپدیت تعداد و حذف
    path('update-cart-item/', views.update_cart_item, name='update_cart_item'),

    # سبد خرید - محتوای مودال (AJAX)
    path('cart-modal-content/', views.cart_modal_content, name='cart_modal_content'),
    path('checkout/', views.checkout, name='checkout'),
    path('create-order/', views.create_order, name='create_order'),
    path('cart-count/', views.get_cart_count, name='cart_count'),

    # احراز هویت
    path('register/', views.register_view, name='register'),
    path('login/', views.login_view, name='login'),
    path('logout/', views.logout_view, name='logout'),
    path('dashboard/', views.dashboard, name='dashboard'),
    path('profile/', views.profile_view, name='profile'),
    path('orders/', views.orders_view, name='orders'),
    path('order/<int:order_id>/', views.order_detail, name='order_detail'),

]
